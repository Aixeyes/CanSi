class UserSession {
  // In-memory session cache for the current user's email.
  static String? email;
  // In-memory session cache for the current user's id.
  static int? userId;
}
